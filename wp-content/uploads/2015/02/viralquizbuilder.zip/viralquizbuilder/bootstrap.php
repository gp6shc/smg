<?php
if( !defined( 'ABSPATH' ) )	exit;

require_once 'core/VQzBuilder_Core.class.php';
require_once 'core/VQzBuilder.class.php';
require_once 'core/VQzBuilder_ModelCore.class.php';
require_once 'core/VQzBuilder_ActivationManager.class.php';  
require_once 'core/VQzBuilder_Admin.class.php'; 
require_once 'core/VQzBuilder_FrontEnd.class.php';
require_once 'plugin-updates/plugin-update-checker.php';

 